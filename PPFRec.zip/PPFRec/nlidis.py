import json
import random
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util
import torch
import time
import math


# Haversine formula to calculate distance between two lat/long points
def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Radius of the Earth in kilometers
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    distance = R * c  # Distance in kilometers
    return distance


# 加载商户数据
def load_business_data(file_path, num_samples, random_seed):
    businesses = []
    texts = []
    random.seed(random_seed)
    print("Loading businesses from JSON...")

    with open(file_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(tqdm(f)):
            data = json.loads(line)
            if not (data.get("name") and data.get("categories")):
                continue

            business = {
                "business_id": data["business_id"],
                "name": data["name"],
                "categories": data["categories"],
                "attributes": data.get("attributes", {}),
                "latitude": data.get("latitude", 0),  # Assuming latitude in data
                "longitude": data.get("longitude", 0),  # Assuming longitude in data
            }
            text = f"{data['name']}, {data['categories']}"

            if len(businesses) < num_samples:
                businesses.append(business)
                texts.append(text)
            else:
                r = random.randint(0, idx)
                if r < num_samples:
                    businesses[r] = business
                    texts[r] = text

    print(f"Sampled {len(businesses)} businesses.")
    return businesses, texts


# 提取查询中的条件
def extract_conditions_from_query(query):
    keywords = {
        "romantic": ["romantic", "date", "couple", "lover"],
        "quiet": ["quiet", "silent", "peaceful"],
        "birthday": ["birthday", "celebrate birthday", "birthday package", "special occasion"],
        "pets": ["pet", "pets allowed", "dog friendly", "bring pets", "pet friendly"],
    }
    query = query.lower()
    matched_conditions = []

    for key, related_words in keywords.items():
        for word in related_words:
            if word in query:
                matched_conditions.append(key)
                break

    return list(set(matched_conditions))


# 检查商户是否符合条件
def filter_business(biz, required_conditions):
    if not required_conditions:
        return True

    attributes = biz.get("attributes") or {}
    if isinstance(attributes, str):
        try:
            attributes = json.loads(attributes.replace("'", '"'))
        except:
            attributes = {}

    ambience = attributes.get("Ambience", {})
    if isinstance(ambience, str):
        try:
            ambience = json.loads(ambience.replace("'", '"'))
        except:
            ambience = {}

    for cond in required_conditions:
        if cond == "romantic":
            if ambience.get("romantic") is False:
                return False
        elif cond == "pets":
            if attributes.get("DogsAllowed") in ["False", "false", "u'false'", False]:
                return False
    return True


# 计算商户与当前位置的距离并分类
# 计算商户与当前位置的距离并分类
# 计算商户与当前位置的距离并分类
def classify_by_distance(businesses, current_lat, current_lon):
    within_1km = 0
    within_1_to_2km = 0
    within_2_to_3km = 0
    within_3_to_4km = 0
    within_4_to_5km = 0

    for score, business in businesses:  # Here business is the second element of the tuple
        business_lat = business.get("latitude", 0)
        business_lon = business.get("longitude", 0)
        if business_lat != 0 and business_lon != 0:
            distance = haversine(current_lat, current_lon, business_lat, business_lon)
            if distance < 10:
                within_1km += 1
            elif 10 <= distance < 20:
                within_1_to_2km += 1
            elif 20 <= distance < 30:
                within_2_to_3km += 1
            elif 30 <= distance < 40:
                within_3_to_4km += 1
            elif 40 <= distance < 50:
                within_4_to_5km += 1

    return within_1km, within_1_to_2km, within_2_to_3km, within_3_to_4km, within_4_to_5km




# 开始计时
start_time = time.time()

# 配置
yelp_json_path = "yelp.json"
embedding_output_path = "business_embeddings.pt"
batch_size = 128
num_samples = 2000  # 商家数量

# 假设当前位置
current_lat = 40
current_lon = -86

# 初始化累积商户个数
total_within_1km = 0
total_within_1_to_2km = 0
total_within_2_to_3km = 0
total_within_3_to_4km = 0
total_within_4_to_5km = 0


# 加载模型
model = SentenceTransformer('sentence-transformers/bert-base-nli-mean-tokens')

# 读取商户数据
sampled_businesses, sampled_texts = load_business_data(yelp_json_path, num_samples, random_seed=42)

# 计算商户的embedding
print("Encoding all businesses...")
business_embeddings = model.encode(
    sampled_texts,
    batch_size=batch_size,
    convert_to_tensor=True,
    show_progress_bar=True
)

# 保存embeddings
torch.save({
    "businesses": sampled_businesses,
    "embeddings": business_embeddings
}, embedding_output_path)

print(f"All done! Embeddings saved to {embedding_output_path}")

# 加载embedding
data = torch.load(embedding_output_path)
businesses = data["businesses"]
business_embeddings = data["embeddings"]

# 输入查询
queries = [
    "I want to find a restaurant where I can drink tea or coffee, preferably a pet friendly restaurant where pets can also eat.",
    "Please recommend a romantic restaurant for couples, ideally with a quiet atmosphere and private seating."

]

# 查询编码
query_embeddings = model.encode(queries, convert_to_tensor=True)

# TCR计算
total_filtered_biz = set()  # 用集合来去重商户

# # 计算每个请求的商户距离
# for query, query_embedding in zip(queries, query_embeddings):
#     cos_scores = util.cos_sim(query_embedding, business_embeddings)[0]
#     top_results = torch.topk(cos_scores, k=num_samples)  # 先取Top32
#
#     required_conditions = extract_conditions_from_query(query)
#
#     filtered_biz = []
#     for score, idx in zip(top_results.values, top_results.indices):
#         if score < 0.5:
#             continue  # 得分太低的不考虑
#         biz = businesses[idx]
#         if filter_business(biz, required_conditions):
#             filtered_biz.append((score, biz))
#             total_filtered_biz.add(biz['business_id'])  # 使用商户ID来去重

    # # 分类商户的距离
    # within_1km, within_1_to_2km = classify_by_distance(filtered_biz, current_lat, current_lon)
    #
    # print(f"Query: \"{query}\" - {within_1km} businesses within 1 km, {within_1_to_2km} businesses within 1-2 km")

# 假设这是你从所有查询得到的商户数据（filtered_biz 是每个查询得到的商户列表）
for query, query_embedding in zip(queries, query_embeddings):
    # 检索并筛选商户
    cos_scores = util.cos_sim(query_embedding, business_embeddings)[0]
    top_results = torch.topk(cos_scores, k=num_samples)  # 先取Top32

    required_conditions = extract_conditions_from_query(query)

    filtered_biz = []
    for score, idx in zip(top_results.values, top_results.indices):
        if score < 0.5:
            continue  # 得分太低的不考虑
        biz = businesses[idx]
        if filter_business(biz, required_conditions):
            filtered_biz.append((score, biz))
            total_filtered_biz.add(biz['business_id'])  # 使用商户ID来去重

    # 根据距离分类并累积结果
    within_1km, within_1_to_2km, within_2_to_3km, within_3_to_4km, within_4_to_5km = classify_by_distance(filtered_biz,
                                                                                                          current_lat,
                                                                                                          current_lon)

    total_within_1km += within_1km
    total_within_1_to_2km += within_1_to_2km
    total_within_2_to_3km += within_2_to_3km
    total_within_3_to_4km += within_3_to_4km
    total_within_4_to_5km += within_4_to_5km

# 输出每个距离范围的商户数量
print(f"Total number of businesses within 1 km: {total_within_1km}")
print(f"Total number of businesses between 1 km and 2 km: {total_within_1_to_2km}")
print(f"Total number of businesses between 2 km and 3 km: {total_within_2_to_3km}")
print(f"Total number of businesses between 3 km and 4 km: {total_within_3_to_4km}")
print(f"Total number of businesses between 4 km and 5 km: {total_within_4_to_5km}")

# 计算任务覆盖率（TCR）
TCR = len(total_filtered_biz) / num_samples
print(f"\nTotal Task Coverage Rate (TCR): {TCR:.6f}")

end_time = time.time()
elapsed_time = end_time - start_time
print(f"Elapsed time: {elapsed_time:.2f} seconds")
