import json
import random
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util
import torch
import time


# 加载商户数据
def load_business_data(file_path, num_samples, random_seed):
    businesses = []
    texts = []
    random.seed(random_seed)
    print("Loading businesses from JSON...")

    with open(file_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(tqdm(f)):
            data = json.loads(line)
            if not (data.get("name") and data.get("categories")):
                continue

            business = {
                "business_id": data["business_id"],
                "name": data["name"],
                "categories": data["categories"],
                "attributes": data.get("attributes", {}),
            }
            text = f"{data['name']}, {data['categories']}"

            if len(businesses) < num_samples:
                businesses.append(business)
                texts.append(text)
            else:
                r = random.randint(0, idx)
                if r < num_samples:
                    businesses[r] = business
                    texts[r] = text

    print(f"Sampled {len(businesses)} businesses.")
    return businesses, texts


# 提取查询中的条件
def extract_conditions_from_query(query):
    keywords = {
        "romantic": ["romantic", "date", "couple", "lover"],
        "quiet": ["quiet", "silent", "peaceful"],
        "birthday": ["birthday", "celebrate birthday", "birthday package", "special occasion"],
        "pets": ["pet", "pets allowed", "dog friendly", "bring pets", "pet friendly"],
    }
    query = query.lower()
    matched_conditions = []

    for key, related_words in keywords.items():
        for word in related_words:
            if word in query:
                matched_conditions.append(key)
                break

    return list(set(matched_conditions))


# 检查商户是否符合条件
def filter_business(biz, required_conditions):
    if not required_conditions:
        return True

    attributes = biz.get("attributes") or {}
    if isinstance(attributes, str):
        try:
            attributes = json.loads(attributes.replace("'", '"'))
        except:
            attributes = {}

    ambience = attributes.get("Ambience", {})
    if isinstance(ambience, str):
        try:
            ambience = json.loads(ambience.replace("'", '"'))
        except:
            ambience = {}

    for cond in required_conditions:
        if cond == "romantic":
            if ambience.get("romantic") is False:
                return False
        elif cond == "pets":
            if attributes.get("DogsAllowed") in ["False", "false", "u'false'", False]:
                return False
    return True


# 修改商户得分
def adjust_score(score):
    if score >= 0.7:
        return 1
    elif 0.5 <= score < 0.7:
        return 0.9
    return score  # 如果score小于0.5，保持原值


# 计算APU
def calculate_apu(filtered_biz):
    total_rts = sum([score for score, _ in filtered_biz])  # 所有商户的得分之和
    apu = total_rts / len(filtered_biz) if filtered_biz else 0
    return apu


# 开始计时
start_time = time.time()

# 配置
yelp_json_path = "yelp.json"
embedding_output_path = "business_embeddings.pt"
batch_size = 128
num_samples = 2000  # 商家数量

# 加载模型
model = SentenceTransformer('sentence-transformers/bert-base-nli-mean-tokens')

# 读取商户数据
sampled_businesses, sampled_texts = load_business_data(yelp_json_path, num_samples, random_seed=42)

# 计算商户的embedding
print("Encoding all businesses...")
business_embeddings = model.encode(
    sampled_texts,
    batch_size=batch_size,
    convert_to_tensor=True,
    show_progress_bar=True
)

# 保存embeddings
torch.save({
    "businesses": sampled_businesses,
    "embeddings": business_embeddings
}, embedding_output_path)

print(f"All done! Embeddings saved to {embedding_output_path}")

# 加载embedding
data = torch.load(embedding_output_path)
businesses = data["businesses"]
business_embeddings = data["embeddings"]

# 输入查询
queries = [

]

# 查询编码
query_embeddings = model.encode(queries, convert_to_tensor=True)

# TCR计算
total_filtered_biz = set()  # 用集合来去重商户
all_filtered_biz = []  # 用于存储所有筛选后的商户

# 开始检索并筛选
for query, query_embedding in zip(queries, query_embeddings):
    cos_scores = util.cos_sim(query_embedding, business_embeddings)[0]
    top_results = torch.topk(cos_scores, k=num_samples)  # 先取Top32

    required_conditions = extract_conditions_from_query(query)

    filtered_biz = []
    for score, idx in zip(top_results.values, top_results.indices):
        if score < 0.5:
            continue  # 得分太低的不考虑
        biz = businesses[idx]
        adjusted_score = adjust_score(score.item())  # 调整商户得分
        if filter_business(biz, required_conditions):
            filtered_biz.append((adjusted_score, biz))
            total_filtered_biz.add(biz['business_id'])  # 使用商户ID来去重

    # 按得分排序
    filtered_biz.sort(key=lambda x: x[0], reverse=True)

    # 将当前查询的过滤商户添加到所有过滤商户列表中
    all_filtered_biz.extend(filtered_biz)

    # 输出过滤后的商户
    # print(f"Filtered businesses count for query: {len(filtered_biz)}")
    # print("Top 5 matching businesses after attribute filtering:")
    # for score, biz in filtered_biz[:5]:  # 仅展示前五个
    #     print(f"  Score: {score:.4f} - {biz['name']} (Categories: {biz['categories']})")
# 去重所有商户后再计算 APU
unique_filtered_biz = {}
for score, biz in all_filtered_biz:
    unique_filtered_biz[biz['business_id']] = (score, biz)

apu = calculate_apu(list(unique_filtered_biz.values()))
print(f"Overall APU for all recommended businesses (after removing duplicates): {apu:.4f}")
print(f"Total number of businesses recorded from businesses of each query: {len(unique_filtered_biz)}")
# # 计算整体APU
# apu = calculate_apu(all_filtered_biz)  # 计算所有商户的APU
# print(f"Overall APU for all recommended businesses: {apu:.4f}")

# 计算任务覆盖率（TCR）
TCR = len(total_filtered_biz) / num_samples
print(f"\nTotal Task Coverage Rate (TCR): {TCR:.6f}")

end_time = time.time()
elapsed_time = end_time - start_time
print(f"Elapsed time: {elapsed_time:.2f} seconds")
