import json
import random
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util
import torch
import time
import math


# Haversine formula to calculate distance between two lat/long points
def haversine(lat1, lon1, lat2, lon2):
    R = 6371  # Radius of the Earth in kilometers
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = math.sin(delta_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    distance = R * c  # Distance in kilometers
    return distance


# 加载商户数据
def load_business_data(file_path, num_samples, random_seed):
    businesses = []
    texts = []
    random.seed(random_seed)
    print("Loading businesses from JSON...")

    with open(file_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(tqdm(f)):
            data = json.loads(line)
            if not (data.get("name") and data.get("categories")):
                continue

            business = {
                "business_id": data["business_id"],
                "name": data["name"],
                "categories": data["categories"],
                "attributes": data.get("attributes", {}),
                "latitude": data.get("latitude", 0),  # Assuming latitude in data
                "longitude": data.get("longitude", 0),  # Assuming longitude in data
            }
            text = f"{data['name']}, {data['categories']}"

            if len(businesses) < num_samples:
                businesses.append(business)
                texts.append(text)
            else:
                r = random.randint(0, idx)
                if r < num_samples:
                    businesses[r] = business
                    texts[r] = text

    print(f"Sampled {len(businesses)} businesses.")
    return businesses, texts


# 提取查询中的条件
def extract_conditions_from_query(query):
    keywords = {
        "romantic": ["romantic", "date", "couple", "lover"],
        "quiet": ["quiet", "silent", "peaceful"],
        "birthday": ["birthday", "celebrate birthday", "birthday package", "special occasion"],
        "pets": ["pet", "pets allowed", "dog friendly", "bring pets", "pet friendly"],
    }
    query = query.lower()
    matched_conditions = []

    for key, related_words in keywords.items():
        for word in related_words:
            if word in query:
                matched_conditions.append(key)
                break

    return list(set(matched_conditions))


# 检查商户是否符合条件
def filter_business(biz, required_conditions):
    if not required_conditions:
        return True

    attributes = biz.get("attributes") or {}
    if isinstance(attributes, str):
        try:
            attributes = json.loads(attributes.replace("'", '"'))
        except:
            attributes = {}

    ambience = attributes.get("Ambience", {})
    if isinstance(ambience, str):
        try:
            ambience = json.loads(ambience.replace("'", '"'))
        except:
            ambience = {}

    for cond in required_conditions:
        if cond == "romantic":
            if ambience.get("romantic") is False:
                return False
        elif cond == "pets":
            if attributes.get("DogsAllowed") in ["False", "false", "u'false'", False]:
                return False
    return True


# 计算商户与当前位置的距离并分类
def classify_by_distance(businesses, current_lat, current_lon):
    within_1km = []
    within_1_to_2km = []
    within_2_to_3km = []
    within_3_to_4km = []
    within_4_to_5km = []

    for score, business in businesses:  # Here business is the second element of the tuple
        business_lat = business.get("latitude", 0)
        business_lon = business.get("longitude", 0)
        if business_lat != 0 and business_lon != 0:
            distance = haversine(current_lat, current_lon, business_lat, business_lon)
            if distance < 10:
                within_1km.append((score, business))
            elif 10 <= distance < 20:
                within_1_to_2km.append((score, business))
            elif 20 <= distance < 30:
                within_2_to_3km.append((score, business))
            elif 30 <= distance < 40:
                within_3_to_4km.append((score, business))
            elif 40 <= distance < 50:
                within_4_to_5km.append((score, business))

    return within_1km, within_1_to_2km, within_2_to_3km, within_3_to_4km, within_4_to_5km


# 修改商户得分
def adjust_score(score):
    if score >= 0.7:
        return 1
    elif 0.5 <= score < 0.7:
        return 0.9
    return score  # 如果score小于0.5，保持原值


# 计算APU
def calculate_apu(filtered_biz):
    total_rts = sum([score for score, _ in filtered_biz])  # 所有商户的得分之和
    apu = total_rts / len(filtered_biz) if filtered_biz else 0  # 除以商户数量计算平均 APU
    return apu

# 开始计时
start_time = time.time()

# 配置
yelp_json_path = "yelp.json"
embedding_output_path = "business_embeddings.pt"
batch_size = 128
num_samples = 2000  # 商家数量

# 假设当前位置
current_lat = 40
current_lon = -86

# 初始化累积商户个数
total_within_1km = 0
total_within_1_to_2km = 0
total_within_2_to_3km = 0
total_within_3_to_4km = 0
total_within_4_to_5km = 0


# 加载模型
model = SentenceTransformer('sentence-transformers/bert-base-nli-mean-tokens')

# 读取商户数据
sampled_businesses, sampled_texts = load_business_data(yelp_json_path, num_samples, random_seed=42)

# 计算商户的embedding
print("Encoding all businesses...")
business_embeddings = model.encode(
    sampled_texts,
    batch_size=batch_size,
    convert_to_tensor=True,
    show_progress_bar=True
)

# 保存embeddings
torch.save({
    "businesses": sampled_businesses,
    "embeddings": business_embeddings
}, embedding_output_path)

print(f"All done! Embeddings saved to {embedding_output_path}")

# 加载embedding
data = torch.load(embedding_output_path)
businesses = data["businesses"]
business_embeddings = data["embeddings"]

# 输入查询
queries = [
    "I want to find a restaurant that can bring pets, preferably a tea restaurant.",
    "Recommend a romantic restaurant suitable for a date, ideally with a private atmosphere.",
    "I need a place suitable for celebrating a birthday, with special birthday packages and reservation services.",
    "I want a gym where I can exercise and assess my physical condition.",
    "I want a health clinic that can provide medical treatment and medication.",
    "I need a place that offers car services and auto repair, ideally with good reviews.",
    "Recommend a hotel with a garden that can host events and provide spacious venues for large groups.",
    "Recommend a shop with a beautiful environment where you can do nail art.",
    "I’m looking for a travel agency specializing in adventure tours, with an emphasis on outdoor activities.",
    "Recommend a repair service center that specializes in fixing home appliances.",
    "Recommend a store where you can buy many plants and floral tools.",
    "Recommend a bar that offers a variety of drinks and a vibrant nightlife experience.",
    "Find a shopping center that offers a variety of clothing, including a fashion store.",
    "Recommend a beauty salon for hair care services, ideally with a relaxing ambiance.",
    "I need a restaurant offering traditional American food, with a casual atmosphere and great service.",
    "I need a restaurant serving seafood, with a focus on fresh ingredients and excellent customer service.",
    "Please recommend a restaurant that serves Mexican food, with a cozy atmosphere and excellent customer reviews.",
    "I need a restaurant that serves pizza, with both traditional and new options.",
    "Find a restaurant serving sandwiches, with both traditional and new options, and a casual setting.",
    "Please recommend a pet-friendly restaurant that also serves breakfast and has outdoor seating.",
    "Find a restaurant offering both traditional and specialty dishes, with a cozy setting.",
    "Find a hotel with wellness services, ideally located near a garden or outdoor setting.",
    "Find a bar that serves a variety of drinks, including beer, with a lively atmosphere for nightlife.",
    "Please recommend a beauty salon that offers skin care services.",
    "I’m looking for a car dealership that offers a variety of vehicles and great customer service.",
    "I need a shop that can provide home repair services for pipeline maintenance and pest control.",
    "Find a shopping center with a variety of stores, including fashion and home goods.",
    "Please recommend a store with ice cream or yogurt.",
    "Recommend a dental clinic that can perform routine examinations.",
    "Recommend a store where pets can be bathed and styled.",
    "I want to find a shop that can do self-service car washing.",
    "Recommend a place where children can receive talent training, preferably with many extracurricular activities.",
    "I want to find a place that can hold large-scale events and provide catering services.",
    "Recommend a photography studio that offers both photo shoots and event photography.",
    "I am looking for an art studio that can customize paintings or sculptures.",
    "I am looking for a furniture decoration store where I can purchase modern furniture.",
    "I’m looking for a tire service center that offers tire changes and balancing services.",
    "Recommend a shop that can provide car repair and painting services.",
    "Recommend a car dealer that sells used cars, preferably with warranty service.",
    "Please recommend a travel agency that specializes in adventure or hiking trips.",
    "Please recommend a travel agency that offers tropical travel programs, preferably including food and accommodation.",
    "I am looking for a real estate company that primarily rents out office space.",
    "Please recommend a cinema with a wide variety of movies and preferably a larger screen.",
    "Recommend a video game entertainment center suitable for young people to play.",
    "Recommend a bowling alley suitable for beginners.",
    "Please recommend a sports equipment store that specializes in selling camping and hiking gear.",
    "I am looking for a company that can rent items needed for parties."
]

# 查询编码
query_embeddings = model.encode(queries, convert_to_tensor=True)

# TCR计算
total_filtered_biz = set()  # 用集合来去重商户

# 开始检索并筛选
for query, query_embedding in zip(queries, query_embeddings):
    cos_scores = util.cos_sim(query_embedding, business_embeddings)[0]
    top_results = torch.topk(cos_scores, k=num_samples)  # 先取Top32

    required_conditions = extract_conditions_from_query(query)

    filtered_biz = []
    for score, idx in zip(top_results.values, top_results.indices):
        if score < 0.5:
            score = 0.5  # 对得分小于 0.5 的商户进行赋值处理
        biz = businesses[idx]
        adjusted_score = adjust_score(score)
        if filter_business(biz, required_conditions):
            filtered_biz.append((adjusted_score, biz))  # 使用调整后的得分
            total_filtered_biz.add(biz['business_id'])  # 使用商户ID来去重

    # 根据距离分类并累积结果
    within_1km, within_1_to_2km, within_2_to_3km, within_3_to_4km, within_4_to_5km = classify_by_distance(filtered_biz,
                                                                                                          current_lat,
                                                                                                          current_lon)

    total_within_1km += len(within_1km)
    total_within_1_to_2km += len(within_1_to_2km)
    total_within_2_to_3km += len(within_2_to_3km)
    total_within_3_to_4km += len(within_3_to_4km)
    total_within_4_to_5km += len(within_4_to_5km)

# 去重：根据商户ID去重并计算每个距离范围内的 APU
def calculate_distance_range_apu(filtered_biz):
    unique_biz = {}
    for score, biz in filtered_biz:
        unique_biz[biz['business_id']] = (score, biz)

    # 计算APU
    return calculate_apu(list(unique_biz.values()))


# 计算每个距离范围内的 APU
apu_within_1km = calculate_distance_range_apu(within_1km)
apu_within_1_to_2km = calculate_distance_range_apu(within_1_to_2km)
apu_within_2_to_3km = calculate_distance_range_apu(within_2_to_3km)
apu_within_3_to_4km = calculate_distance_range_apu(within_3_to_4km)
apu_within_4_to_5km = calculate_distance_range_apu(within_4_to_5km)

# 输出每个距离范围内的商户个数和 APU
print(f"Total businesses within 1 km: {total_within_1km}")
print(f"APU for businesses within 1 km: {apu_within_1km:.4f}")

print(f"Total businesses between 1 km and 2 km: {total_within_1_to_2km}")
print(f"APU for businesses between 1 km and 2 km: {apu_within_1_to_2km:.4f}")

print(f"Total businesses between 2 km and 3 km: {total_within_2_to_3km}")
print(f"APU for businesses between 2 km and 3 km: {apu_within_2_to_3km:.4f}")

print(f"Total businesses between 3 km and 4 km: {total_within_3_to_4km}")
print(f"APU for businesses between 3 km and 4 km: {apu_within_3_to_4km:.4f}")

print(f"Total businesses between 4 km and 5 km: {total_within_4_to_5km}")
print(f"APU for businesses between 4 km and 5 km: {apu_within_4_to_5km:.4f}")

# 计算任务覆盖率（TCR）
TCR = len(total_filtered_biz) / num_samples
print(f"\nTotal Task Coverage Rate (TCR): {TCR:.6f}")

end_time = time.time()
elapsed_time = end_time - start_time
print(f"Elapsed time: {elapsed_time:.2f} seconds")
