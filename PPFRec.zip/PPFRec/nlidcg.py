import json
import random
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util
import torch
import time

# 加载商户数据
def load_business_data(file_path, num_samples, random_seed):
    businesses = []
    texts = []
    random.seed(random_seed)
    print("Loading businesses from JSON...")

    with open(file_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(tqdm(f)):
            data = json.loads(line)
            if not (data.get("name") and data.get("categories")):
                continue

            business = {
                "business_id": data["business_id"],
                "name": data["name"],
                "categories": data["categories"],
                "attributes": data.get("attributes", {}),
            }
            text = f"{data['name']}, {data['categories']}"

            if len(businesses) < num_samples:
                businesses.append(business)
                texts.append(text)
            else:
                r = random.randint(0, idx)
                if r < num_samples:
                    businesses[r] = business
                    texts[r] = text

    print(f"Sampled {len(businesses)} businesses.")
    return businesses, texts


# 提取查询中的条件
def extract_conditions_from_query(query):
    keywords = {
        "romantic": ["romantic", "date", "couple", "lover"],
        "quiet": ["quiet", "silent", "peaceful"],
        "birthday": ["birthday", "celebrate birthday", "birthday package", "special occasion"],
        "pets": ["pet", "pets allowed", "dog friendly", "bring pets", "pet friendly"],
    }
    query = query.lower()
    matched_conditions = []

    for key, related_words in keywords.items():
        for word in related_words:
            if word in query:
                matched_conditions.append(key)
                break

    return list(set(matched_conditions))


# 检查商户是否符合条件
def filter_business(biz, required_conditions):
    if not required_conditions:
        return True

    attributes = biz.get("attributes") or {}
    if isinstance(attributes, str):
        try:
            attributes = json.loads(attributes.replace("'", '"'))
        except:
            attributes = {}

    ambience = attributes.get("Ambience", {})
    if isinstance(ambience, str):
        try:
            ambience = json.loads(ambience.replace("'", '"'))
        except:
            ambience = {}

    for cond in required_conditions:
        if cond == "romantic":
            if ambience.get("romantic") is False:
                return False
        elif cond == "pets":
            if attributes.get("DogsAllowed") in ["False", "false", "u'false'", False]:
                return False
    return True


# NDCG计算
def calculate_dcg(relevance_scores):
    dcg = 0
    for i, score in enumerate(relevance_scores):
        dcg += score / torch.log2(torch.tensor(i + 2.0))  # 索引从0开始，所以i+2
    return dcg

def calculate_idcg(relevance_scores):
    # 按降序排列relevance_scores并取前5个
    ideal_relevance_scores = sorted(relevance_scores, reverse=True)
    return calculate_dcg(ideal_relevance_scores)

def calculate_ndcg(dcg, idcg):
    if idcg == 0:
        return 0
    return dcg / idcg

# 开始计时
start_time = time.time()

# 配置
yelp_json_path = "yelp_sampled_1000.json"
embedding_output_path = "business_embeddings.pt"
batch_size = 128
num_samples = 1000  # 商家数量

# 加载模型
model = SentenceTransformer('sentence-transformers/bert-base-nli-mean-tokens')

# 读取商户数据
sampled_businesses, sampled_texts = load_business_data(yelp_json_path, num_samples, random_seed=42)

# 计算商户的embedding
print("Encoding all businesses...")
business_embeddings = model.encode(
    sampled_texts,
    batch_size=batch_size,
    convert_to_tensor=True,
    show_progress_bar=True
)

# 保存embeddings
torch.save({
    "businesses": sampled_businesses,
    "embeddings": business_embeddings
}, embedding_output_path)

print(f"All done! Embeddings saved to {embedding_output_path}")

# 加载embedding
data = torch.load(embedding_output_path)
businesses = data["businesses"]
business_embeddings = data["embeddings"]

# 输入查询
queries = [
    "I want to find a restaurant that can bring pets, preferably a tea restaurant.",
"Recommend a romantic restaurant suitable for a date, ideally with a private atmosphere.",
"Please recommend a romantic restaurant for couples, ideally with a quiet atmosphere and private seating.",
    "I want to find a restaurant where I can drink tea or coffee, preferably a pet friendly restaurant where pets can also eat."
]

# 查询编码
query_embeddings = model.encode(queries, convert_to_tensor=True)

# TCR计算
total_filtered_biz = set()  # 用集合来去重商户

# 开始检索并筛选
for query, query_embedding in zip(queries, query_embeddings):
    cos_scores = util.cos_sim(query_embedding, business_embeddings)[0]

    # 过滤出得分大于等于0.5的商户
    filtered_scores = [(score.item(), idx) for idx, score in enumerate(cos_scores) if score >= 0.5]

    # 提取前五个商户的信息
    relevance_scores = []
    filtered_biz = []
    for score, idx in filtered_scores[:5]:  # 只取符合条件的前5个商户
        biz = businesses[idx]
        filtered_biz.append((score, biz))
        # 直接使用推荐商户的得分作为相关性分数
        relevance_scores.append(score)

    # 输出DCG使用的五个商户信息
    # print("\nDCG - Top 5 recommended businesses:")
    # for score, biz in filtered_biz:
    #     print(f"  Score: {score:.4f} - {biz['name']} (Categories: {biz['categories']})")


    # 计算DCG
    dcg = calculate_dcg(relevance_scores)  # 只计算前五个商户的DCG

    # 计算IDCG
    # 对所有商户得分进行降序排序，选择前5个商户计算IDCG
    all_scores = [(score.item(), idx) for idx, score in enumerate(cos_scores)]
    all_scores.sort(reverse=True, key=lambda x: x[0])  # 按得分降序排序
    idcg_scores = [score for score, idx in all_scores[:5]]  # 取前五个的得分

    # # 输出IDCG使用的五个商户信息
    # print("\nIDCG - Top 5 ideal businesses (sorted by score):")
    # for score, idx in zip(idcg_scores, [idx for _, idx in all_scores[:5]]):
    #     biz = businesses[idx]
    #     print(f"  Score: {score:.4f} - {biz['name']} (Categories: {biz['categories']})")

    idcg = calculate_dcg(idcg_scores)

    # 计算NDCG
    ndcg = calculate_ndcg(dcg, idcg)

    print(f"Query: \"{query}\" - NDCG@5: {ndcg:.4f}")
    # print(f"Filtered businesses count: {len(filtered_biz)}")
    # for all_scores, biz in filtered_biz[:5]:  # 仅展示前五个
    #     print(f"  Score: {score:.4f} - {biz['name']} (Categories: {biz['categories']})")

# 计算任务覆盖率（TCR）
TCR = len(total_filtered_biz) / num_samples
print(f"\nTotal Task Coverage Rate (TCR): {TCR:.6f}")

end_time = time.time()
elapsed_time = end_time - start_time
print(f"Elapsed time: {elapsed_time:.2f} seconds")
