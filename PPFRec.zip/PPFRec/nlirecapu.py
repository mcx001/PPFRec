import json
import random
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util
import torch
import time

# 加载商户数据
def load_business_data(file_path, num_samples, random_seed):
    businesses = []
    texts = []
    random.seed(random_seed)
    print("Loading businesses from JSON...")

    with open(file_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(tqdm(f)):
            data = json.loads(line)
            if not (data.get("name") and data.get("categories")):
                continue

            business = {
                "business_id": data["business_id"],
                "name": data["name"],
                "categories": data["categories"],
                "attributes": data.get("attributes", {}),
            }
            text = f"{data['name']}, {data['categories']}"

            if len(businesses) < num_samples:
                businesses.append(business)
                texts.append(text)
            else:
                r = random.randint(0, idx)
                if r < num_samples:
                    businesses[r] = business
                    texts[r] = text

    print(f"Sampled {len(businesses)} businesses.")
    return businesses, texts


# 提取查询中的条件
def extract_conditions_from_query(query):
    keywords = {
        "romantic": ["romantic", "date", "couple", "lover"],
        "quiet": ["quiet", "silent", "peaceful"],
        "birthday": ["birthday", "celebrate birthday", "birthday package", "special occasion"],
        "pets": ["pet", "pets allowed", "dog friendly", "bring pets", "pet friendly"],
    }
    query = query.lower()
    matched_conditions = []

    for key, related_words in keywords.items():
        for word in related_words:
            if word in query:
                matched_conditions.append(key)
                break

    return list(set(matched_conditions))


# 检查商户是否符合条件
def filter_business(biz, required_conditions):
    if not required_conditions:
        return True

    attributes = biz.get("attributes") or {}
    if isinstance(attributes, str):
        try:
            attributes = json.loads(attributes.replace("'", '"'))
        except:
            attributes = {}

    ambience = attributes.get("Ambience", {})
    if isinstance(ambience, str):
        try:
            ambience = json.loads(ambience.replace("'", '"'))
        except:
            ambience = {}

    for cond in required_conditions:
        if cond == "romantic":
            if ambience.get("romantic") is False:
                return False
        elif cond == "pets":
            if attributes.get("DogsAllowed") in ["False", "false", "u'false'", False]:
                return False
    return True

# 修改商户得分
def adjust_score(score):
    if score >= 0.7:
        return 1
    elif 0.5 <= score < 0.7:
        return 0.9
    return score  # 如果score小于0.5，保持原值


# 计算APU
def calculate_apu(filtered_biz):
    total_rts = sum([score for score, _ in filtered_biz])  # 所有商户的得分之和
    apu = total_rts / len(filtered_biz) if filtered_biz else 0  # 除以商户数量计算平均 APU
    return apu

# 开始计时
start_time = time.time()

# 配置
yelp_json_path = "yelp.json"
embedding_output_path = "business_embeddings.pt"
batch_size = 128
num_samples = 2000  # 商家数量

# 加载模型
model = SentenceTransformer('sentence-transformers/bert-base-nli-mean-tokens')

# 读取商户数据
sampled_businesses, sampled_texts = load_business_data(yelp_json_path, num_samples, random_seed=42)

# 计算商户的embedding
print("Encoding all businesses...")
business_embeddings = model.encode(
    sampled_texts,
    batch_size=batch_size,
    convert_to_tensor=True,
    show_progress_bar=True
)

# 保存embeddings
torch.save({
    "businesses": sampled_businesses,
    "embeddings": business_embeddings
}, embedding_output_path)

print(f"All done! Embeddings saved to {embedding_output_path}")

# 加载embedding
data = torch.load(embedding_output_path)
businesses = data["businesses"]
business_embeddings = data["embeddings"]

# 输入查询
queries = [
    "I want to find a restaurant where I can drink tea or coffee, preferably a pet friendly restaurant where pets can also eat.",
    "Please recommend a romantic restaurant for couples, ideally with a quiet atmosphere and private seating.",
    "I need a restaurant suitable for a birthday celebration, ideally offering birthday packages and reservation services, with a special atmosphere for the occasion.",
    "I need a fitness center that offers active sports facilities and health services.",
    "Please recommend a health clinic that provides general medical services, emergency care, and medication.",
    "I’m looking for a car repair shop, preferably with great customer service and quick service.",
    "I need a hotel with a garden and event planning services, preferably also providing health services.",
    "Find a nail salon that offers a variety of services and has a relaxing environment.",
    "Recommend a travel agency that offers high-quality vacation packages, has good customer reviews, and has many adventure tourism projects.",
    "Find a place that provides home appliance repair services, preferably with an experienced team and quick response.",
    "I need a garden center market that offers plants and gardening tools, with expert advice.",
    "Find a bar with a wide variety of alcoholic beverages, fast food, and an excellent nightlife atmosphere.",
    "Find a shopping center with various stores, especially home decor and fashion stores with local and international fashion brands.",
    "I am looking for a beauty salon specializing in haircuts, styling, and hair care, preferably with a relaxed atmosphere.",
    "I need a restaurant that serves Mexican or traditional American cuisine, with a truly relaxed atmosphere and good service.",
    "Please recommend a restaurant with seafood and a comfortable environment. The ingredients should be fresh, and traditional and specialty foods should be provided with high-quality service.",
    "Find a restaurant that serves pizza or sandwiches, with traditional and innovative food options, outdoor seating, and a relaxed environment.",
    "Find a restaurant that serves Chinese cuisine or offers breakfast and lunch, with good service and high reviews.",
    "Recommend a hotel that is close to a garden or has an outdoor environment, has convenient transportation, and provides health services.",
    "Please recommend a beauty salon that offers waxing and skin care services.",
    "Recommend a bar that offers a variety of beverages and drinks, including beer, wine, etc., with an active atmosphere.",
    "Find a home service provider that can handle various home repairs, including plumbing, HVAC, and pest control.",
    "Recommend a shopping center with a wide variety of options, including supermarkets, where you can purchase furniture, supplies, fashion, and more.",
    "I want a car dealership where I can view vehicles from various brands and make vehicle purchases, preferably with high-quality service.",
    "Recommend a store with ice cream or yogurt, no space restrictions.",
    "Find a dental clinic, ideally offering routine check-ups and emergency services.",
    "Recommend a pet grooming service, offering bath and grooming services for pets.",
    "Recommend a car wash center, preferably with self-service and automatic washing options.",
    "Find a training center for children's education, ideally with various extracurricular activities and specialized tutors.",
    "I’m looking for an event venue that can host large gatherings, ideally with catering services available.",
    "I need a photography studio that offers professional portrait and event photography.",
    "Looking for a custom art shop that specializes in commissioned paintings and sculptures.",
    "Find a home décor store that specializes in modern, minimalist furniture and accessories.",
    "Looking for an auto body shop that provides collision repair and paint services.",
    "Recommend an auto car repair shop or service center that can provide services such as painting and tire replacement for cars.",
    "Please recommend an auto dealership that sells used cars, with warranties and financing options.",
    "Please recommend a travel agency that specializes in adventure tours and guided hiking trips.",
    "Find a travel agency that offers vacation packages to tropical destinations, including flights and accommodations.",
    "I’m looking for a commercial real estate agent who can help with office space leasing.",
    "Looking for a real estate agency that provides virtual home tours for out-of-town buyers.",
    "I’m looking for a movie theater that offers a variety of films, including indie and international films.",
    "Find an arcade or amusement center with a variety of games and fun activities for all ages.",
    "I need a bowling alley that offers both casual and competitive bowling leagues.",
    "Looking for a sports shop that sells outdoor equipment, including camping and hiking gear.",
    "Find a party supply rental service, ideally offering a variety of decorations and event equipment."
]

# 查询编码
query_embeddings = model.encode(queries, convert_to_tensor=True)

# 存储每个请求的前两个商户
top_2_biz_all_queries = []

for query, query_embedding in zip(queries, query_embeddings):
    cos_scores = util.cos_sim(query_embedding, business_embeddings)[0]
    top_results = torch.topk(cos_scores, k=num_samples)  # 取前N个商户

    required_conditions = extract_conditions_from_query(query)

    filtered_biz = []
    for score, idx in zip(top_results.values, top_results.indices):
        if score < 0.5:
            continue  # 忽略得分低的商户
        biz = businesses[idx]
        if filter_business(biz, required_conditions):
            filtered_biz.append((score, biz))

    # 按得分排序，取前两个商户
    filtered_biz.sort(key=lambda x: x[0], reverse=True)
    top_biz = filtered_biz[:4]  # 只取前两个商户

    # 调整前两个商户的分数
    adjusted_top_biz = [(adjust_score(score), biz) for score, biz in top_biz]

    # 记录这些商户
    top_2_biz_all_queries.extend(adjusted_top_biz)

# 去重：根据商户ID去重
unique_top_2_biz_all_queries = {}
for score, biz in top_2_biz_all_queries:
    unique_top_2_biz_all_queries[biz['business_id']] = (score, biz)

# 计算所有请求的前两个商户的 APU
total_apu = calculate_apu(list(unique_top_2_biz_all_queries.values()))  # 计算去重后的总 APU


# 输出总 APU
print(f"Total APU for all top 2 recommended businesses across all queries: {total_apu:.4f}")
# 输出 `top_2_biz_all_queries` 的数量
print(f"Total number of businesses recorded from top 2 businesses of each query: {len(unique_top_2_biz_all_queries)}")

# 计算任务覆盖率（TCR）
TCR = len(top_2_biz_all_queries) / num_samples
print(f"\nTotal Task Coverage Rate (TCR): {TCR:.6f}")

end_time = time.time()
elapsed_time = end_time - start_time
print(f"Elapsed time: {elapsed_time:.2f} seconds")
