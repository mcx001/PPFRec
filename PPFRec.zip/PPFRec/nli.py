import json
import random
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util
import torch
import time

# 加载商户数据
def load_business_data(file_path, num_samples, random_seed):
    businesses = []
    texts = []
    random.seed(random_seed)
    print("Loading businesses from JSON...")

    with open(file_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(tqdm(f)):
            data = json.loads(line)
            if not (data.get("name") and data.get("categories")):
                continue

            business = {
                "business_id": data["business_id"],
                "name": data["name"],
                "categories": data["categories"],
                "attributes": data.get("attributes", {}),
            }
            text = f"{data['name']}, {data['categories']}"

            if len(businesses) < num_samples:
                businesses.append(business)
                texts.append(text)
            else:
                r = random.randint(0, idx)
                if r < num_samples:
                    businesses[r] = business
                    texts[r] = text

    print(f"Sampled {len(businesses)} businesses.")
    return businesses, texts


# 提取查询中的条件
def extract_conditions_from_query(query):
    keywords = {
        "romantic": ["romantic", "date", "couple", "lover"],
        "quiet": ["quiet", "silent", "peaceful"],
        "birthday": ["birthday", "celebrate birthday", "birthday package", "special occasion"],
        "pets": ["pet", "pets allowed", "dog friendly", "bring pets", "pet friendly"],
    }
    query = query.lower()
    matched_conditions = []

    for key, related_words in keywords.items():
        for word in related_words:
            if word in query:
                matched_conditions.append(key)
                break

    return list(set(matched_conditions))


# 检查商户是否符合条件
def filter_business(biz, required_conditions):
    if not required_conditions:
        return True

    attributes = biz.get("attributes") or {}
    if isinstance(attributes, str):
        try:
            attributes = json.loads(attributes.replace("'", '"'))
        except:
            attributes = {}

    ambience = attributes.get("Ambience", {})
    if isinstance(ambience, str):
        try:
            ambience = json.loads(ambience.replace("'", '"'))
        except:
            ambience = {}

    for cond in required_conditions:
        if cond == "romantic":
            if ambience.get("romantic") is False:
                return False
        elif cond == "pets":
            if attributes.get("DogsAllowed") in ["False", "false", "u'false'", False]:
                return False
    return True

# 开始计时
start_time = time.time()

# 配置
yelp_json_path = "yelp.json"
embedding_output_path = "business_embeddings.pt"
batch_size = 512
num_samples = 2000 # 商家数量

# 加载模型
model = SentenceTransformer('sentence-transformers/bert-base-nli-mean-tokens')

# 读取商户数据
sampled_businesses, sampled_texts = load_business_data(yelp_json_path, num_samples, random_seed=42)

# 计算商户的embedding
print("Encoding all businesses...")
business_embeddings = model.encode(
    sampled_texts,
    batch_size=batch_size,
    convert_to_tensor=True,
    show_progress_bar=True
)

# 保存embeddings
torch.save({
    "businesses": sampled_businesses,
    "embeddings": business_embeddings
}, embedding_output_path)

print(f"All done! Embeddings saved to {embedding_output_path}")

# 加载embedding
data = torch.load(embedding_output_path)
businesses = data["businesses"]
business_embeddings = data["embeddings"]

# 输入查询
queries = [
    "I want to find a restaurant that can bring pets, preferably a tea restaurant.",
    "Recommend a romantic restaurant suitable for a date, ideally with a private atmosphere.",
    "I need a place suitable for celebrating a birthday, with special birthday packages and reservation services.",
    "I want a gym where I can exercise and assess my physical condition.",
    "I want a health clinic that can provide medical treatment and medication.",
    "I need a place that offers car services and auto repair, ideally with good reviews.",
    "Recommend a hotel with a garden that can host events and provide spacious venues for large groups.",
    "Recommend a shop with a beautiful environment where you can do nail art.",
    "I’m looking for a travel agency specializing in adventure tours, with an emphasis on outdoor activities.",
    "Recommend a repair service center that specializes in fixing home appliances.",
    "Recommend a store where you can buy many plants and floral tools.",
    "Recommend a bar that offers a variety of drinks and a vibrant nightlife experience.",
    "Find a shopping center that offers a variety of clothing, including a fashion store.",
    "Recommend a beauty salon for hair care services, ideally with a relaxing ambiance.",
    "I need a restaurant offering traditional American food, with a casual atmosphere and great service.",
    "I need a restaurant serving seafood, with a focus on fresh ingredients and excellent customer service.",
    "Please recommend a restaurant that serves Mexican food, with a cozy atmosphere and excellent customer reviews.",
    "I need a restaurant that serves pizza, with both traditional and new options.",
    "Find a restaurant serving sandwiches, with both traditional and new options, and a casual setting.",
    "Please recommend a pet-friendly restaurant that also serves breakfast and has outdoor seating.",
    "Find a restaurant offering both traditional and specialty dishes, with a cozy setting.",
    "Find a hotel with wellness services, ideally located near a garden or outdoor setting.",
    "Find a bar that serves a variety of drinks, including beer, with a lively atmosphere for nightlife.",
    "Please recommend a beauty salon that offers skin care services.",
    "I’m looking for a car dealership that offers a variety of vehicles and great customer service.",
    "I need a shop that can provide home repair services for pipeline maintenance and pest control.",
    "Find a shopping center with a variety of stores, including fashion and home goods.",
    "Please recommend a store with ice cream or yogurt.",
    "Recommend a dental clinic that can perform routine examinations.",
    "Recommend a store where pets can be bathed and styled.",
    "I want to find a shop that can do self-service car washing.",
    "Recommend a place where children can receive talent training, preferably with many extracurricular activities.",
    "I want to find a place that can hold large-scale events and provide catering services.",
    "Recommend a photography studio that offers both photo shoots and event photography.",
    "I am looking for an art studio that can customize paintings or sculptures.",
    "I am looking for a furniture decoration store where I can purchase modern furniture.",
    "I’m looking for a tire service center that offers tire changes and balancing services.",
    "Recommend a shop that can provide car repair and painting services.",
    "Recommend a car dealer that sells used cars, preferably with warranty service.",
    "Please recommend a travel agency that specializes in adventure or hiking trips.",
    "Please recommend a travel agency that offers tropical travel programs, preferably including food and accommodation.",
    "I am looking for a real estate company that primarily rents out office space.",
    "Please recommend a cinema with a wide variety of movies and preferably a larger screen.",
    "Recommend a video game entertainment center suitable for young people to play.",
    "Recommend a bowling alley suitable for beginners.",
    "Please recommend a sports equipment store that specializes in selling camping and hiking gear.",
    "I am looking for a company that can rent items needed for parties."

]

# 查询编码
query_embeddings = model.encode(queries, convert_to_tensor=True)

# TCR计算
total_filtered_biz = set()  # 用集合来去重商户

# 开始检索并筛选
for query, query_embedding in zip(queries, query_embeddings):
    # query_start_time = time.time()  # 开始计时
    cos_scores = util.cos_sim(query_embedding, business_embeddings)[0]
    top_results = torch.topk(cos_scores, k=num_samples)  # 先取Top32

    required_conditions = extract_conditions_from_query(query)
    # print(f"\nQuery: {query}")
    # print(f"Extracted conditions: {required_conditions}")

    filtered_biz = []
    for score, idx in zip(top_results.values, top_results.indices):
        if score < 0.5:
            continue  # 得分太低的不考虑
        biz = businesses[idx]
        if filter_business(biz, required_conditions):
            filtered_biz.append((score, biz))
            total_filtered_biz.add(biz['business_id'])  # 使用商户ID来去重

    # 按得分排序
    filtered_biz.sort(key=lambda x: x[0], reverse=True)
    # query_end_time = time.time()  # 结束计时
    # query_elapsed = query_end_time - query_start_time
    # print(f"Query: \"{query}\" - matched {len(filtered_biz)} businesses - time taken: {query_elapsed:.2f} seconds")

    # # 过滤出得分大于等于0.5的商户
    # filtered_scores = [(score.item(), idx) for idx, score in enumerate(cos_scores) if score >= 0.5]
    # # 提取前五个商户的信息
    # relevance_scores = []
    # filtered_biz = []
    # for score, idx in filtered_scores[:30]:  # 只取符合条件的前5个商户
    #     biz = businesses[idx]
    #     filtered_biz.append((score, biz))
    #     # 直接使用推荐商户的得分作为相关性分数
    #     relevance_scores.append(score)
    # # 输出DCG使用的五个商户信息
    # print("\nDCG - Top 5 recommended businesses:")
    # for score, biz in filtered_biz:
    #     print(f"  Score: {score:.4f} - {biz['name']} (Categories: {biz['categories']})")


    # print(f"Filtered businesses count: {len(filtered_biz)}")
    # print("Top 5 matching businesses after attribute filtering:")
    # for score, biz in filtered_biz[:30]:  # 仅展示前五个
    #     print(f"  Score: {score:.4f} - {biz['name']} (Categories: {biz['categories']})")
# 输出 total_filtered_biz 的个数，即最后的推荐商户个数
print(f"Total number of recommended businesses: {len(total_filtered_biz)}")

# Check the content of total_filtered_biz to debug
# print("First 5 business IDs in total_filtered_biz for debugging:")
# print(list(total_filtered_biz)[:5])

# Output all recommended businesses with 'name' and 'categories'
# recommended_businesses = []
# for biz_id in total_filtered_biz:
#     # Find the business by ID in the businesses list
#     biz = next((b for b in businesses if b['business_id'] == biz_id), None)
#     if biz:
#         recommended_businesses.append({
#             "name": biz["name"],
#             "categories": biz["categories"]
#         })

# # Debugging: Print the first 5 recommended businesses
# print("First 5 recommended businesses for output:")
# for business in recommended_businesses[:5]:
#     print(business)

# # Write the recommended businesses to a JSON file
# output_file = "recommended_businesses_b_5000.json"
# with open(output_file, 'w', encoding='utf-8') as f:
#     for business in recommended_businesses:
#         json.dump(business, f, ensure_ascii=False)
#         f.write("\n")  # Ensure each business is on a new line
# print(f"Recommended businesses details saved to {output_file}")


# 计算任务覆盖率（TCR）
TCR = len(total_filtered_biz) / num_samples
print(f"\nTotal Task Coverage Rate (TCR): {TCR:.6f}")

end_time = time.time()
elapsed_time = end_time - start_time
print(f"Elapsed time: {elapsed_time:.2f} seconds")


