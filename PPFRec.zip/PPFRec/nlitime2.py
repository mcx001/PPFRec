import json
import random
import torch
import time
from tqdm import tqdm
from sentence_transformers import SentenceTransformer, util

# 检查CUDA
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Using device: {device}")

# 加载商户数据
def load_business_data(file_path, num_samples, random_seed=42):
    businesses, texts = [], []
    random.seed(random_seed)
    with open(file_path, 'r', encoding='utf-8') as f:
        for idx, line in enumerate(f):
            data = json.loads(line)
            if not (data.get("name") and data.get("categories")):
                continue
            if len(businesses) < num_samples:
                businesses.append(data)
                texts.append(f"{data['name']}, {data['categories']}")
            else:
                r = random.randint(0, idx)
                if r < num_samples:
                    businesses[r] = data
                    texts[r] = f"{data['name']}, {data['categories']}"
    return businesses, texts

# 查询条件提取
def extract_conditions_from_query(query):
    keywords = {
        "romantic": ["romantic", "date", "couple", "lover"],
        "quiet": ["quiet", "silent", "peaceful"],
        "birthday": ["birthday", "celebrate birthday", "birthday package"],
        "pets": ["pet", "pets allowed", "dog friendly", "bring pets"]
    }
    query = query.lower()
    return [key for key, words in keywords.items() if any(w in query for w in words)]

# 商户过滤
def filter_business(biz, required_conditions):
    if not required_conditions:
        return True
    attributes = biz.get("attributes") or {}
    if isinstance(attributes, str):
        try:
            attributes = json.loads(attributes.replace("'", '"'))
        except:
            attributes = {}
    if not isinstance(attributes, dict):
        attributes = {}
    ambience = attributes.get("Ambience", {})
    if isinstance(ambience, str):
        try:
            ambience = json.loads(ambience.replace("'", '"'))
        except:
            ambience = {}
    if not isinstance(ambience, dict):
        ambience = {}

    for cond in required_conditions:
        if cond == "romantic" and not ambience.get("romantic", True):
            return False
        if cond == "pets" and attributes.get("DogsAllowed") in ["False", "false", False]:
            return False
    return True

# 参数
yelp_json_path = "yelp.json"
embedding_output_path = "business_embeddings.pt"
batch_size = 1024  # 加大batch
num_samples = 2000

# 开始计时
star_time = time.time()

# 加载模型到GPU，使用半精度
model = SentenceTransformer('sentence-transformers/bert-base-nli-mean-tokens', device=device)
if device == 'cuda':
    model = model.half()
# 加载数据
businesses, texts = load_business_data(yelp_json_path, num_samples)

# 总时间
en_time = time.time()
print(f"Elapsed time: {en_time - star_time:.2f} seconds")
# 开始计时
start_time = time.time()
# 计算embedding
print("Encoding businesses...")
business_embeddings = model.encode(
    texts,
    batch_size=batch_size,
    convert_to_tensor=True,
    device=device,
    normalize_embeddings=True,
    show_progress_bar=True,
    num_workers=4
)

# 保存
torch.save({"businesses": businesses, "embeddings": business_embeddings}, embedding_output_path)

# 加载embedding
data = torch.load(embedding_output_path, map_location=device)
businesses = data["businesses"]
business_embeddings = data["embeddings"]

# 查询
queries = [
    "I want to find a restaurant where I can drink tea or coffee, preferably a pet friendly restaurant where pets can also eat.",
    "Please recommend a romantic restaurant for couples, ideally with a quiet atmosphere and private seating.",
    "I need a restaurant suitable for a birthday celebration, ideally offering birthday packages and reservation services, with a special atmosphere for the occasion.",
    "I need a fitness center that offers active sports facilities and health services.",
    "Please recommend a health clinic that provides general medical services, emergency care, and medication.",
    "I’m looking for a car repair shop, preferably with great customer service and quick service.",
    "I need a hotel with a garden and event planning services, preferably also providing health services.",
    "Find a nail salon that offers a variety of services and has a relaxing environment.",
    "Recommend a travel agency that offers high-quality vacation packages, has good customer reviews, and has many adventure tourism projects.",
    "Find a place that provides home appliance repair services, preferably with an experienced team and quick response.",
    "I need a garden center market that offers plants and gardening tools, with expert advice.",
    "Find a bar with a wide variety of alcoholic beverages, fast food, and an excellent nightlife atmosphere.",
    "Find a shopping center with various stores, especially home decor and fashion stores with local and international fashion brands.",
    "I am looking for a beauty salon specializing in haircuts, styling, and hair care, preferably with a relaxed atmosphere.",
    "I need a restaurant that serves Mexican or traditional American cuisine, with a truly relaxed atmosphere and good service.",
    "Please recommend a restaurant with seafood and a comfortable environment. The ingredients should be fresh, and traditional and specialty foods should be provided with high-quality service.",
    "Find a restaurant that serves pizza or sandwiches, with traditional and innovative food options, outdoor seating, and a relaxed environment.",
    "Find a restaurant that serves Chinese cuisine or offers breakfast and lunch, with good service and high reviews.",
    "Recommend a hotel that is close to a garden or has an outdoor environment, has convenient transportation, and provides health services.",
    "Please recommend a beauty salon that offers waxing and skin care services.",
    "Recommend a bar that offers a variety of beverages and drinks, including beer, wine, etc., with an active atmosphere.",
    "Find a home service provider that can handle various home repairs, including plumbing, HVAC, and pest control.",
    "Recommend a shopping center with a wide variety of options, including supermarkets, where you can purchase furniture, supplies, fashion, and more.",
    "I want a car dealership where I can view vehicles from various brands and make vehicle purchases, preferably with high-quality service.",
    "Recommend a store with ice cream or yogurt, no space restrictions.",
    "Find a dental clinic, ideally offering routine check-ups and emergency services.",
    "Recommend a pet grooming service, offering bath and grooming services for pets.",
    "Recommend a car wash center, preferably with self-service and automatic washing options.",
    "Find a training center for children's education, ideally with various extracurricular activities and specialized tutors.",
    "I’m looking for an event venue that can host large gatherings, ideally with catering services available.",
    "I need a photography studio that offers professional portrait and event photography.",
    "Looking for a custom art shop that specializes in commissioned paintings and sculptures.",
    "Find a home décor store that specializes in modern, minimalist furniture and accessories.",
    "Looking for an auto body shop that provides collision repair and paint services.",
    "Recommend an auto car repair shop or service center that can provide services such as painting and tire replacement for cars.",
    "Please recommend an auto dealership that sells used cars, with warranties and financing options.",
    "Please recommend a travel agency that specializes in adventure tours and guided hiking trips.",
    "Find a travel agency that offers vacation packages to tropical destinations, including flights and accommodations.",
    "I’m looking for a commercial real estate agent who can help with office space leasing.",
    "Looking for a real estate agency that provides virtual home tours for out-of-town buyers.",
    "I’m looking for a movie theater that offers a variety of films, including indie and international films.",
    "Find an arcade or amusement center with a variety of games and fun activities for all ages.",
    "I need a bowling alley that offers both casual and competitive bowling leagues.",
    "Looking for a sports shop that sells outdoor equipment, including camping and hiking gear.",
    "Find a party supply rental service, ideally offering a variety of decorations and event equipment."
]

# 批量编码所有queries
query_embeddings = model.encode(
    queries,
    batch_size=batch_size,
    convert_to_tensor=True,
    device=device,
    normalize_embeddings=True,
    show_progress_bar=True,
    num_workers=4
)

# 一次性计算所有余弦相似度
all_cos_scores = util.cos_sim(query_embeddings, business_embeddings)

# 检索
print("Retrieving...")
total_filtered_biz = set()

for query_idx, query in enumerate(queries):
    cos_scores = all_cos_scores[query_idx]
    top_scores, top_indices = torch.topk(cos_scores, k=num_samples)
    required_conditions = extract_conditions_from_query(query)

    for score, idx in zip(top_scores, top_indices):
        if score < 0.5:
            continue
        biz = businesses[idx]
        if filter_business(biz, required_conditions):
            total_filtered_biz.add(biz['business_id'])

print(f"Total number of recommended businesses: {len(total_filtered_biz)}")

# 计算TCR
TCR = len(total_filtered_biz) / num_samples
print(f"\nTotal Task Coverage Rate (TCR): {TCR:.6f}")

# 总时间
end_time = time.time()
print(f"Elapsed time: {end_time - start_time:.2f} seconds")
